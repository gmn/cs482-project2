Work Allocation

proj.py - Contributions were made by all three team members throughout the creation of this project.
README.txt - Andrew Sellers, with verification from Cameron Clapp and Gregory Naughton.
PeerEvaluation_<yourname>.txt - Andrew Sellers, filled out by all three individually.
Testing/Formatting - All three tested and verified to make sure everything was functional and formatted properly.

Communication was handled through Discord throughout the course of this assignment.